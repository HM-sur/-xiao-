
Simple Drop down list
""""""""""""""""""""""

.. lv_example:: widgets/dropdown/lv_example_dropdown_1
  :language: c

Drop down in four directions
""""""""""""""""""""""""""""

.. lv_example:: widgets/dropdown/lv_example_dropdown_2
  :language: c


Menu
""""""""""""

.. lv_example:: widgets/dropdown/lv_example_dropdown_3
  :language: c

